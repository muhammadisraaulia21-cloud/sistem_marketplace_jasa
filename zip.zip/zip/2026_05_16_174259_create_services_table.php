<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('services', function (Blueprint $table) {
            $table->id();
            
            // Tambahkan 4 baris ini:
            $table->foreignId('user_id')->constrained()->onDelete('cascade'); // Siapa yang punya jasa ini
            $table->string('title'); // Judul Jasa (contoh: Jasa Desain Logo)
            $table->text('description'); // Deskripsi lengkap jasanya
            $table->integer('price'); // Harga jasa
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('services');
    }
};
